import React, { Component } from "react";
import "./App.css";

export default class App extends Component {
  state = {
    inputValue: 0,
    objectOfDispensedNotes: {
      2000: 0,
      500: 0,
      200: 0,
      100: 0,
      50: 0,
      20: 0,
      10: 0,
      1: 0
    }
  };

  handleInputChange(e) {
    const inputValue = e.target.value;
    this.setState({
      inputValue
    });
  }

  mapValueToCurrencyDenominations() {
    let totalAmount = this.state.inputValue;
    const objectOfDispensedNotes = Object.entries(
      this.state.objectOfDispensedNotes
    )
      .reverse()
      .reduce((accumulator, [key]) => {
        // @TODO: write the logic here to calculate all the denominations of the input currency

      }, {});
    // @TODO: update the state here
    this.setState({ objectOfDispensedNotes });
  }

  render() {
    return (
      <div className="App">
        <h1>ATM Dispenser</h1>
        {/* @TODO: attach on change event handler on the input below
            to update the input value in the state} */}
        <input
          type="text"
          value={this.state.inputValue}
        />
        <div style={{ marginTop: "16px" }}>
          {/* @TODO:  assign `mapValueToCurrencyDenominations` method to the on click
           event of the button below */}
          <button onClick={}>
            Show Denominations
          </button>
        </div>
        <h2>Denominations of the input value below</h2>
        {Object.entries(this.state.objectOfDispensedNotes)
          .reverse()
          .map(([key, value]) => (
            // @TODO: Provide each paragraph child unique stable identity
            <p>
              Notes of Rs. {key}: {value}
            </p>
          ))}
      </div>
    );
  }
}