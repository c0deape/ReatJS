import multiply from './multiply';

it('multiply numbers', () => {
  expect(multiply(4, 3)).toEqual(12);
  expect(multiply(-6, 7)).toEqual(-42);
});