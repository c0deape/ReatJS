/** 
 * @TODO
 * Write a function that accepts the array and substring as parameters
 * and returns the new array that contains elements those contain the substring only
 */


export default filter;
