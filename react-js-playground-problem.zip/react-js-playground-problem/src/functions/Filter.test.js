import filter from './filter';

it('filters array values that do not contains the substring', () => {
  const substring = '789';
  const arrayOfValues = ['Test 123 Test', '123456789', 'ABC DEF 123', '7 8 9'];
  const arrayOfExpectedValues = ['123456789'];
  filter(arrayOfValues, substring).then(filteredArray => {
    expect(filteredArray).toEqual(arrayOfExpectedValues);
  });
});