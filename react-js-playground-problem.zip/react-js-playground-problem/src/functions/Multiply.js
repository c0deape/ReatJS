/**
 * @TODO
 * Write a function that performs multiplication of two integers 
 * without using multiplication, division and bitwise operators, and no loops. 
 * Function should accept two parameters, x and y.
 * x or y can be negative also
 */


export default multiply;